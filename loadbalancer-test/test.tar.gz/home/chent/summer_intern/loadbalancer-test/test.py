while(1):
    a = 1
    a+=1
